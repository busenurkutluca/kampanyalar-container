export const sahteVeri = [
  {
    src: 'https://i.ibb.co/pR25Ks6/winter.jpg',
    title: 'Kış Kampanyası',
    text: '%50 indirimli ürünler sizi bekliyor',
    id: 1,
  },
  {
    src: 'https://i.ibb.co/6FMQMFf/pizza.jpg',
    title: 'Gel Al Kampanyası',
    text: '2. pizza bedava',
    id: 2,
  },
  {
    src: 'https://i.ibb.co/0mvwD5D/fries.jpg',
    title: 'Yanında Pazatates Kızartması',
    text: 'Büyük boy alana bedava',
    id: 3,
  },
];
