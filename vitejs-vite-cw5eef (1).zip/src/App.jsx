import Header from './components/Header';
import Footer from './components/Footer';
import './components/Layout.css';
import Offer from './components/Offer';
import 'bootstrap/dist/css/bootstrap.min.css';
/* ADIM 2? */

function App() {
  return (
    <>
      <Header />
      <div className="content-section">
        <Offer> </Offer>
        {/* ADIM 3: Offer component'ini burada kullanabilirsin */}
      </div>
      <Footer />
    </>
  );
}

export default App;
