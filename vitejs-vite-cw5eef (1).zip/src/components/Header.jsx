function Header(props) {
  const { searchText, handleSearch } = props;

  return (
    <header>
      <h1>WiStore Kampanyalar</h1>
    </header>
  );
}

export default Header;
